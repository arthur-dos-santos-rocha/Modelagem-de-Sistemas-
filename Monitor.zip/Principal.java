package attmonitor;

public  class Principal{
    public static void main(String []args){
        
        Monitor monitor = new Monitor(24,"LED",1000.0);
        
        monitor.setTamanho(24);
        monitor.setTipoTela("LED");
        monitor.setPreco(1000.0);
        
        Computador computador = new Computador();
        
        computador.setMarca("DEL");
        computador.setCor("Preto");
        computador.setModelo("Inspiron");
        computador.setValor(2500.0);
        computador.setMonitor(monitor);
        
        System.out.println("O valor total do computador"+ computador.getMarca()
        +"com o montor de "+computador.getMonitor().getTamanho()+"Polegadas"+
        computador.getMonitor().getTipoTela()+"Ficou de: R$"+computador.calcularValorTotal());
    }

}