package attmonitor;

public class Monitor {
    private int tamanho;
    private String tipoTela;
    private double preco;

  
    public Monitor(int tamanho, String tipoTela, double preco) {
        this.tamanho = tamanho;
        this.tipoTela = tipoTela;
        this.preco = preco;
    }

    public int getTamanho() {
        return tamanho;
    }

    public void setTamanho(int tamanho) {
        this.tamanho = tamanho;
    }

    public String getTipoTela() {
        return tipoTela;
    }

    public void setTipoTela(String tipoTela) {
        this.tipoTela = tipoTela;
    }

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }
}