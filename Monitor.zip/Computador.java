package attmonitor;

public class Computador {
    private String marca;
    private String cor;
    private String modelo;
    private double valor;
    private Monitor monitor;

    public Computador() {
    }

    public Computador(String marca, String cor, String modelo, double valor, Monitor monitor) {
        this.marca = marca;
        this.cor = cor;
        this.modelo = modelo;
        this.valor = valor;
        this.monitor = monitor;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public Monitor getMonitor() {
        return monitor;
    }

    public void setMonitor(Monitor monitor) {
        this.monitor = monitor;
    }

    public double calcularValorTotal() {
        return valor + monitor.getPreco();
    }
}